/**
 * 체크리스트 상태 저장소 추상화
 *
 * 우선순위:
 *   1) VITE_SHEETS_WEBAPP_URL 가 설정되어 있으면 Google Sheets (Apps Script 웹앱)
 *   2) 그렇지 않으면 localStorage fallback
 *
 * Sheets 연동은 apps-script/Code.gs 를 Apps Script 에 배포한 뒤
 * 웹앱 URL 을 .env.local 에 VITE_SHEETS_WEBAPP_URL 로 넣으면 자동 활성화됩니다.
 */

export type ChecklistState = Record<string, boolean>

export interface ChecklistStore {
  load(): Promise<ChecklistState>
  save(state: ChecklistState): Promise<void>
  readonly mode: 'sheets' | 'local'
}

const LS_KEY = 'kcbc:checklist'

class LocalStorageStore implements ChecklistStore {
  mode = 'local' as const
  async load(): Promise<ChecklistState> {
    try {
      const raw = localStorage.getItem(LS_KEY)
      return raw ? JSON.parse(raw) : {}
    } catch {
      return {}
    }
  }
  async save(state: ChecklistState): Promise<void> {
    localStorage.setItem(LS_KEY, JSON.stringify(state))
  }
}

class SheetsStore implements ChecklistStore {
  mode = 'sheets' as const
  constructor(
    private webappUrl: string,
    private userId: string,
  ) {}

  async load(): Promise<ChecklistState> {
    const url = `${this.webappUrl}?action=load&userId=${encodeURIComponent(this.userId)}`
    const res = await fetch(url, { method: 'GET' })
    if (!res.ok) throw new Error(`Sheets load failed: ${res.status}`)
    const json = (await res.json()) as { ok: boolean; state?: ChecklistState }
    return json.state ?? {}
  }

  async save(state: ChecklistState): Promise<void> {
    // Apps Script 웹앱은 text/plain 으로 보내는 게 CORS 충돌이 가장 적음
    await fetch(this.webappUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action: 'save', userId: this.userId, state }),
    })
  }
}

export function createChecklistStore(): ChecklistStore {
  const url = import.meta.env.VITE_SHEETS_WEBAPP_URL
  const userId = import.meta.env.VITE_SHEETS_USER_ID || 'default'
  if (url && url.length > 0) {
    return new SheetsStore(url, userId)
  }
  return new LocalStorageStore()
}
