import { useMemo } from 'react'
import { loadKCBCData } from './lib/data'
import { createChecklistStore } from './lib/checklistStore'

import HeroHeader from './components/HeroHeader'
import KpiStrip from './components/KpiStrip'
import PillarGrid from './components/PillarGrid'
import FlowSteps from './components/FlowSteps'
import CompareCards from './components/CompareCards'
import QuestionGrid from './components/QuestionGrid'
import Checklist from './components/Checklist'

export default function App() {
  // 마크다운은 빌드타임 import → 한 번만 파싱
  const data = useMemo(() => loadKCBCData(), [])
  const store = useMemo(() => createChecklistStore(), [])

  return (
    <div className="wrap">
      <HeroHeader storeMode={store.mode} />
      <KpiStrip
        pillars={data.pillars.length || 5}
        steps={data.steps.length || 7}
        questions={data.questions.length || 5}
      />
      <PillarGrid pillars={data.pillars} />
      <FlowSteps steps={data.steps} />
      <CompareCards
        propositional={data.lessons.propositional}
        procedural={data.lessons.procedural}
      />
      <QuestionGrid items={data.questions} />
      <Checklist items={data.checklist} store={store} />
      <div className="foot">
        KCBC Dashboard (React) · 출처: kcbc/CLAUDE.md, kcbc/스킬.md ·
        마크다운 변경 시 자동 반영
      </div>
    </div>
  )
}
