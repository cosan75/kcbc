/**
 * KCBC 대시보드 — 체크리스트 상태 저장용 Apps Script 웹앱
 *
 * ▼ 배포 절차
 * 1. https://script.google.com 에서 새 프로젝트 생성
 * 2. 이 파일 내용을 그대로 Code.gs 에 붙여넣기
 * 3. 상단 SPREADSHEET_ID 를 본인 시트 ID 로 변경
 *    (시트 URL: https://docs.google.com/spreadsheets/d/{SPREADSHEET_ID}/edit)
 * 4. 시트에 'checklist' 탭을 만들고 첫 행에 헤더 작성:
 *      A: userId   B: checkId   C: checked   D: updatedAt
 * 5. [배포] → [새 배포] → 유형: 웹 앱
 *      - 다음 사용자로 실행: 나
 *      - 액세스 권한: 모든 사용자 (또는 'Google 계정이 있는 모든 사용자')
 * 6. 발급된 웹앱 URL 을 kcbc/.env.local 에 다음과 같이 저장:
 *      VITE_SHEETS_WEBAPP_URL=https://script.google.com/macros/s/.../exec
 *      VITE_SHEETS_USER_ID=teacher@example.com    // 선택 (구분용)
 * 7. npm run dev 재시작
 */

const SPREADSHEET_ID = 'PASTE_YOUR_SPREADSHEET_ID_HERE'
const SHEET_NAME = 'checklist'

function getSheet_() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID)
  let sh = ss.getSheetByName(SHEET_NAME)
  if (!sh) {
    sh = ss.insertSheet(SHEET_NAME)
    sh.appendRow(['userId', 'checkId', 'checked', 'updatedAt'])
  }
  return sh
}

function loadState_(userId) {
  const sh = getSheet_()
  const last = sh.getLastRow()
  if (last < 2) return {}
  const values = sh.getRange(2, 1, last - 1, 3).getValues()
  const state = {}
  for (const [uid, cid, ch] of values) {
    if (String(uid) === String(userId)) {
      state[String(cid)] = Boolean(ch)
    }
  }
  return state
}

function saveState_(userId, state) {
  const sh = getSheet_()
  const last = sh.getLastRow()
  if (last >= 2) {
    // 해당 user 행 모두 삭제 후 재기록 (간단·견고)
    const values = sh.getRange(2, 1, last - 1, 4).getValues()
    const keep = values.filter((r) => String(r[0]) !== String(userId))
    sh.getRange(2, 1, last - 1, 4).clearContent()
    if (keep.length) {
      sh.getRange(2, 1, keep.length, 4).setValues(keep)
    }
  }
  const now = new Date().toISOString()
  const rows = Object.entries(state).map(([cid, ch]) => [userId, cid, !!ch, now])
  if (rows.length) {
    sh.getRange(sh.getLastRow() + 1, 1, rows.length, 4).setValues(rows)
  }
}

function jsonOut_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(
    ContentService.MimeType.JSON,
  )
}

function doGet(e) {
  const action = e.parameter.action
  const userId = e.parameter.userId || 'default'
  try {
    if (action === 'load') {
      return jsonOut_({ ok: true, state: loadState_(userId) })
    }
    return jsonOut_({ ok: false, error: 'unknown action' })
  } catch (err) {
    return jsonOut_({ ok: false, error: String(err) })
  }
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents)
    const action = body.action
    const userId = body.userId || 'default'
    if (action === 'save') {
      saveState_(userId, body.state || {})
      return jsonOut_({ ok: true })
    }
    return jsonOut_({ ok: false, error: 'unknown action' })
  } catch (err) {
    return jsonOut_({ ok: false, error: String(err) })
  }
}
