import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// kcbc/ 폴더 루트에 위치. CLAUDE.md / 스킬.md 를 ?raw import 로 가져온다.
export default defineConfig({
  plugins: [react()],
  server: { port: 5174, strictPort: true },
  assetsInclude: ['**/*.md'],
})
